from time import time, sleep
from sys import argv, exit, stdout
from cPickle import load, dump
from os.path import exists
from os import getenv
import pygame
from camera import Camera



show_ui = getenv("DISPLAY")

if show_ui:
    pygame.init()

def main():
    if len(argv) != 3:
        print("Usage: %s FILENAME SECONDS\nRecord frames from the camera for SECONDS seconds and save them in FILENAME" % argv[0])
        exit(1)
    name = argv[1]
    seconds = int(argv[2])

    # Initialize the camera and record video frames for a few seconds
    # We select a random exposure for each frame to generate a wide range
    # of lighting samples for training
    camera = Camera(training_mode=True)
    record(camera, name, seconds)


def status(text):
    if show_ui:
        pygame.display.set_caption(text)
    stdout.write('\r%s' % text)
    stdout.flush()


def record(camera, filename, seconds):
    """ Record from the camera """

    # Create window so people can see themselves in the camera while we are recording
    if show_ui:
        pygame.display.init()
        pygame.display.set_caption('Loading...')
        screen = pygame.display.set_mode((512, 512))
    
    delay = 3 # Give people a 3 second warning to get ready
    started = time()
    while time() - started < delay:
        status("Recording in %.0f..." % max(0, delay - (time() - started)))
        sleep(0.1)

    frames = []
    started = time()
    while time() - started < seconds:
        frame = camera.next_frame()
        frames.append(frame)

        # Update our progress 
        status("Recording [ %d frames, %3.0fs left ]" % (len(frames), max(0, seconds - (time() - started))))

        # Show the image in a preview window so you can tell if you are in frame
        if show_ui:
            surface = pygame.surfarray.make_surface(frame)
            screen.blit(pygame.transform.scale(surface, (512, 512)), (0,0))
            pygame.display.flip()
            for evt in pygame.event.get():
                    if evt.type == pygame.QUIT:
                        pygame.quit()
                        exit(1)


    print('')

    # Save the frames to a file, appending if one already exists
    if exists(filename):
        print("%s already exists, merging datasets" % filename)
        existing = load(open(filename, 'rb'))
        frames += existing

    stdout.write('Writing %d frames to %s... ' % (len(frames), filename))
    stdout.flush()
    dump(frames, open(filename, 'wb'))
    print('done.')


if __name__ == '__main__':
    main()

