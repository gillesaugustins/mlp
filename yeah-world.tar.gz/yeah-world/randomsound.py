from os.path import join
from glob import glob
from random import choice
from pygame import mixer
from time import sleep



class RandomSound:
    def __init__(self):
        mixer.init()
        self.playing = None

    def play_from(self, path):
        if mixer.music.get_busy() and self.playing == path: return

        filename = choice(glob(join(path, '*.wav')))
        mixer.music.load(filename)
        mixer.music.play()
        self.playing = path

    def wait(self):
        while mixer.music.get_busy():
            sleep(0.1)
    
    def stop(self):
        mixer.music.stop()



if __name__ == '__main__':
    from sys import argv
    rs = RandomSound()
    rs.play_from(argv[1])
    rs.wait()

